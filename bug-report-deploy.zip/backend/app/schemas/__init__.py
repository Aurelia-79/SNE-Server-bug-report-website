"""Pydantic schemas."""

